# MethaneWatch — Full Stack Architecture & GitHub Repository Export

This repository provides a complete working backend (Node.js/Express or FastAPI) coupled with the **Clean HTML/CSS Frontend Prototype** for the **MethaneWatch** satellite methane leak detection platform.

---

## 📁 Repository Directory Structure

```text
methanewatch/
├── .github/
│   └── workflows/
│       └── deploy.yml                # CI/CD automated pipeline
├── backend/
│   ├── server.js                     # Main Express API server & routes
│   ├── package.json                  # Backend dependencies
│   ├── data/
│   │   ├── plumes.json               # Seed multispectral satellite detections
│   │   ├── facilities.json           # Landfill registry & EPA IDs
│   │   └── verifications.json        # Field verification & dispatch logs
│   ├── services/
│   │   ├── satelliteService.js       # Sentinel-5P / MethaneSAT ingestion mock
│   │   ├── epaComplianceService.js   # Subpart W & HH automated calculation
│   │   └── notificationService.js    # Ground crew alert dispatcher
│   └── .env.example
├── public/                           # Clean HTML/CSS Frontend Prototype
│   ├── index.html                    # Screen 1: Regional Satellite Map & Detection Feed
│   ├── plume-detail.html             # Screen 2: Plume Detail & Orbital Telemetry
│   ├── verification.html             # Screen 3: Super-Emitter Verification & Dispatch
│   ├── compliance.html               # Screen 4: Regional Emissions & EPA Compliance
│   ├── css/
│   │   └── styles.css                # Shared design tokens & responsive mobile frame
│   └── js/
│       ├── api.js                    # Fetch client connecting frontend to backend API
│       └── app.js                    # UI interactions, map tabs, filters, & dispatch logic
├── README.md                         # Quickstart, API documentation & deployment guide
└── .gitignore
```

---

## 🛠️ Complete Backend Implementation

### `backend/package.json`
```json
{
  "name": "methanewatch-backend",
  "version": "1.0.0",
  "description": "Orbital multispectral methane detection and EPA compliance API",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "dotenv": "^16.4.5",
    "express": "^4.19.2"
  },
  "devDependencies": {
    "nodemon": "^3.1.4"
  }
}
```

### `backend/server.js`
```javascript
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Serve static frontend prototype from public/
app.use(express.static(path.join(__dirname, '../public')));

// In-memory Database / Mock Store
let facilities = [
  {
    id: "pine-crest",
    name: "Pine Crest Regional Landfill",
    sector: "4B",
    epaId: "TX-88301",
    lat: 31.8956,
    lon: -102.3061,
    fluxRate: 842, // kg/hr
    status: "critical",
    windVector: "14 kt NW (310°)",
    plumeAreaKm2: 1.4,
    confidence: 96.4,
    lastPass: "Sentinel-5P (14m ago)",
    baselineOverrunPct: 42
  },
  {
    id: "solano-valley",
    name: "Solano Valley Waste Facility",
    sector: "2A",
    epaId: "WST-3819",
    lat: 31.9120,
    lon: -102.2850,
    fluxRate: 320,
    status: "moderate",
    windVector: "8 kt NW",
    plumeAreaKm2: 0.4,
    confidence: 88.0,
    lastPass: "MethaneSAT #4092",
    baselineOverrunPct: 15
  },
  {
    id: "oak-ridge",
    name: "Oak Ridge Bio-Solid Basin",
    sector: "1D",
    epaId: "BIO-7712",
    lat: 31.8700,
    lon: -102.3400,
    fluxRate: 42,
    status: "nominal",
    windVector: "5 kt W",
    plumeAreaKm2: 0.1,
    confidence: 94.8,
    lastPass: "Sentinel-5P",
    baselineOverrunPct: 0
  }
];

let verifications = [
  {
    incidentId: "CH4-2024-0982",
    facilityId: "pine-crest",
    facilityName: "Tri-County Municipal Landfill / Pine Crest Sector 4C",
    stage: 3,
    status: "active",
    detectedAt: "14:15 UTC",
    sensorSource: "Sentinel-5P SWIR + AI Atmospheric Inversion",
    fluxRate: 842,
    massVolume24hMT: 20.2,
    co2eEquivalentMT: 505,
    epaPermitOverrunPct: 180,
    stages: [
      { step: 1, name: "Orbital Detection", status: "completed", timestamp: "14:15 UTC" },
      { step: 2, name: "AI Spectral Validation", status: "completed", confidence: "96.4%" },
      { step: 3, name: "Ground Verification", status: "in_progress", unit: "Delta-2 (Marcus Vance)" },
      { step: 4, name: "Mitigation & Well Shut-off", status: "standby" }
    ],
    fieldCrew: {
      callsign: "Delta-2",
      specialist: "Marcus Vance",
      role: "Senior Field Toxicologist",
      gps: { lat: 34.0522, lon: -118.2437 },
      etaMinutes: 18,
      status: "En route to Gate C"
    }
  }
];

let complianceStats = {
  detectedMetricTonsCH4: 142.8,
  momChangePct: -14.0,
  totalLeaksTracked: 18,
  mitigated: 14,
  verifying: 3,
  unresolved: 1,
  meanResponseHours: 4.2,
  responseBenchmarkHours: 24,
  offsetCreditsMTCO2e: 3998,
  subpartCompliant: true,
  dailyFluxCurve: [
    { day: "Day 01", flux: 280, limit: 450 },
    { day: "Day 08", flux: 360, limit: 450 },
    { day: "Day 15", flux: 310, limit: 450 },
    { day: "Day 22", flux: 190, limit: 450 },
    { day: "Day 26", flux: 580, limit: 450 },
    { day: "Today", flux: 842, limit: 450 }
  ]
};

// ==========================================
// REST API ENDPOINTS
// ==========================================

// 1. Get all monitored regional landfill facilities
app.get('/api/facilities', (req, res) => {
  const { status } = req.query;
  if (status && status !== 'all') {
    return res.json(facilities.filter(f => f.status === status));
  }
  res.json(facilities);
});

// 2. Get specific facility & plume details
app.get('/api/facilities/:id', (req, res) => {
  const facility = facilities.find(f => f.id === req.params.id);
  if (!facility) return res.status(404).json({ error: "Facility not found" });
  res.json(facility);
});

// 3. Get active verification incidents
app.get('/api/verifications', (req, res) => {
  res.json(verifications);
});

// 4. Dispatch Ground Crew Action
app.post('/api/verifications/:id/dispatch', (req, res) => {
  const incident = verifications.find(v => v.incidentId === req.params.id);
  if (!incident) return res.status(404).json({ error: "Incident not found" });

  incident.fieldCrew.status = "Dispatched - Arriving at Working Face Cell #3";
  incident.fieldCrew.etaMinutes = 10;
  
  res.json({
    success: true,
    message: "Field crew Delta-2 notified via satellite uplink.",
    incident
  });
});

// 5. Issue Emergency Remediation Order
app.post('/api/verifications/:id/remediation-order', (req, res) => {
  const { id } = req.params;
  const incident = verifications.find(v => v.incidentId === id);
  if (!incident) return res.status(404).json({ error: "Incident not found" });

  incident.stages[3].status = "active";
  res.json({
    success: true,
    orderId: `EPA-ORD-${Date.now()}`,
    complianceStatus: "Mandatory 2-Hour Abatement Notice Transmitted",
    facility: incident.facilityName
  });
});

// 6. Get EPA Compliance & Environmental Metrics
app.get('/api/compliance', (req, res) => {
  res.json(complianceStats);
});

// 7. Generate Cryptographic Dossier (EPA Subpart HH/W)
app.post('/api/compliance/export-dossier', (req, res) => {
  const dossier = {
    exportId: `GHGRP-2024-V3.4-${Date.now()}`,
    generatedAt: new Date().toISOString(),
    sha256: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    subpartsCovered: ["Subpart HH (Municipal Solid Waste Landfills)", "Subpart W (Petroleum & Natural Gas)"],
    totalReportedMethaneMT: complianceStats.detectedMetricTonsCH4,
    facilitiesIncluded: facilities.length,
    status: "CRYPTOGRAPHICALLY_VERIFIED"
  };
  res.json(dossier);
});

app.listen(PORT, () => {
  console.log(`📡 MethaneWatch Server running at http://localhost:${PORT}`);
});
```

---

## 🌐 Public Frontend Client (`public/js/api.js`)
```javascript
const API_BASE = window.location.origin.includes('localhost')
  ? 'http://localhost:3000/api'
  : '/api';

export const MethaneAPI = {
  async getFacilities(status = 'all') {
    const res = await fetch(`${API_BASE}/facilities${status !== 'all' ? `?status=${status}` : ''}`);
    return res.json();
  },
  async getFacility(id) {
    const res = await fetch(`${API_BASE}/facilities/${id}`);
    return res.json();
  },
  async getVerifications() {
    const res = await fetch(`${API_BASE}/verifications`);
    return res.json();
  },
  async dispatchCrew(incidentId) {
    const res = await fetch(`${API_BASE}/verifications/${incidentId}/dispatch`, { method: 'POST' });
    return res.json();
  },
  async issueRemediation(incidentId) {
    const res = await fetch(`${API_BASE}/verifications/${incidentId}/remediation-order`, { method: 'POST' });
    return res.json();
  },
  async getCompliance() {
    const res = await fetch(`${API_BASE}/compliance`);
    return res.json();
  },
  async exportDossier() {
    const res = await fetch(`${API_BASE}/compliance/export-dossier`, { method: 'POST' });
    return res.json();
  }
};
```

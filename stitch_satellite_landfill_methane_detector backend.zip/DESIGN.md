---
name: Orbital Spectral Observation System
colors:
  surface: '#0c1322'
  surface-dim: '#0c1322'
  surface-bright: '#323949'
  surface-container-lowest: '#070e1d'
  surface-container-low: '#141b2b'
  surface-container: '#191f2f'
  surface-container-high: '#232a3a'
  surface-container-highest: '#2e3545'
  on-surface: '#dce2f7'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dce2f7'
  inverse-on-surface: '#293040'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dce6'
  primary: '#e0fdff'
  on-primary: '#00373a'
  primary-container: '#00f2fe'
  on-primary-container: '#006a70'
  inverse-primary: '#00696f'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#fff5f4'
  on-tertiary: '#68000a'
  tertiary-container: '#ffd0cc'
  on-tertiary-container: '#bb1c25'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6ff'
  primary-fixed-dim: '#00dce6'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#0c1322'
  on-background: '#dce2f7'
  surface-variant: '#2e3545'
typography:
  display:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  data-metric:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.02em
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers a mission-critical, scientifically grounded interface engineered for high-precision environmental analytics, orbital tracking, and automated methane plume identification. The target audience comprises environmental data analysts, regulatory inspectors, geospatial engineers, and landfill facility monitors who require split-second anomaly detection and granular telemetry review under varying ambient lighting conditions.

The visual direction pairs **high-tech instrument minimalism** with **spectral data-density**:
- **Tactile Instrument Feel:** Precision telemetry modules, glowing point targets, radar crosshairs, and layered spatial overlays recreate the operational authority of aerospace and geospatial operations centers.
- **Translucent Layering:** Frosted dark-slate panels over real-time multispectral imagery isolate analytics without disconnecting the user from the physical terrain.
- **Strict Visual Hierarchy:** Chromatic saturation is restricted exclusively to signal detection (plumes, status triggers, alert states), ensuring that zero visual noise compromises quantitative evaluation.

## Colors

The palette is anchored in an orbital dark foundation designed to maximize contrast against high-frequency radiometric raster visualizations and vector boundary overlays:

- **Base Canvas & Foundations:** `#0b0f19` forms the fundamental canvas ground. Intermediate panels, floating sheets, and cards sit on `#111827` (Container Base) with borders and structural separators defined by `#1f293d` (Container Border / Muted Slate).
- **Primary Signal (`#00f2fe` — Infrared Cyan):** Used for primary system interactions, active orbital trajectory tracks, active scan boundaries, and short-wave infrared (SWIR) sensor readings.
- **Secondary Alert (`#f59e0b` — Neon Amber):** Signifies elevated methane emission flux, moderate concentration deltas, warning thresholds, and satellite lock-acquisition states.
- **Tertiary Emergency (`#ef4444` — Alert Crimson):** Dedicated strictly to regulatory threshold breaches, critical super-emitter alerts, sensor calibration faults, and acute emission anomalies.
- **Baseline Baseline (`#10b981` — Baseline Emerald):** Indicates verified containment zones, certified baseline sensor sweeps, and compliant emissions signatures.
- **Text & Telemetry Neutral:** Primary readouts utilize `#f9fafb`, secondary telemetry legends use `#9ca3af`, and disabled/auxiliary coordinates utilize `#4b5563`.

## Typography

The type stack combines technical modernism with uncompromising data legibility:

- **Display & Headings (Space Grotesk):** Provides structured geometric rigor for high-level site designations, facility IDs, and major dashboard totals.
- **Interface & Narrative Body (Geist):** Serves general analytical copy, dialog descriptions, and configuration states with high neutral fidelity and low eye fatigue.
- **Telemetry, Coordinates, & Radiometric Values (JetBrains Mono):** Mandatory for all spatial coordinates (latitude/longitude), parts-per-billion (ppb) measurements, wind vectors, timestamps (UTC), and satellite sensor band designations. All numeric data fields must render tabular digits to prevent layout jitter during live telemetry streams.

## Layout & Spacing

The interface prioritizes maximum viewport availability for full-screen cartographic and multispectral imagery:

- **Mobile Viewport Grid:** Utilizes a fluid 4-column column system with `0.75rem` (`12px`) gutters and `1rem` (`16px`) outer margins, leaving interactive controls anchored in floating ergonomic reach zones at the screen bottom.
- **Tablet / Expanded Viewport Grid:** Switches to an 8-column layout with split-pane inspection modules; side panels lock to a 360px structural drawer while the geospatial viewport remains interactive.
- **Z-Index Layout Rhythm:**
  - Base Layer (Z: 0): Full-screen vector tiles, SAR, and thermal multispectral maps.
  - Telemetry Overlay Layer (Z: 10): Reticle HUD, crosshairs, grid coordinates, and scale bars.
  - Interactive Floating HUD (Z: 20): Floating telemetry pill controls, layer switchers, scrubber timelines, and search triggers.
  - Modal/Drawer Layer (Z: 30): Slide-up inspection sheets and spectral flux profiles.

## Elevation & Depth

This system avoids traditional drop shadows, relying on optical layering, tonal contrasts, and ambient light emission:

- **Surface Translucency:** Floating panels and HUD bars use an ultra-dark glass composition: `background: rgba(17, 24, 39, 0.72)` paired with `backdrop-filter: blur(16px)` and a crisp structural stroke: `1px solid rgba(255, 255, 255, 0.08)`.
- **Spectral Bloom (Signal Depth):** Plume anomalies and active radar states introduce a targeted luminous bleed: `box-shadow: 0 0 16px -2px rgba(0, 242, 254, 0.35)` for cyan indicators, and `0 0 16px -2px rgba(239, 68, 68, 0.45)` for critical threshold exceedances.
- **Recessed Data Fields:** Metric containers and sensor readouts use an inset backdrop (`#080c14`) bordered by `#1f293d` to simulate sunken hardware instrument displays.

## Shapes

The design system applies a hybrid shape philosophy: **aerospace pill-shaped floating targets** combined with **precise, angular metric frames**:

- **Floating Controllers & Modals:** Floating navigation bars, active tool selectors, radar toggles, and status tags strictly follow the Pill geometry (`roundedness: 3`) to maximize tactile thumb targeting and maintain separation from background vector maps.
- **Data Matrix Displays & Sheets:** Sliding analytical drawers and tabular data modules utilize clipped `0.5rem` (`rounded-md`) corners to maintain high-density data packaging without wasting screen estate.

## Components

### Buttons & Telemetry Triggers
- **Primary Pill Trigger:** `height: 44px`, background: `#00f2fe`, text: `#0b0f19` (JetBrains Mono, bold, 12px uppercase). Micro-glow on active state.
- **Glass Action Pill:** `height: 40px`, background: `rgba(17, 24, 39, 0.8)`, border: `1px solid rgba(0, 242, 254, 0.4)`, text: `#f9fafb`. Icon aligned left with mono coordinate or mode label right.
- **Critical Alert Trigger:** Background: `#ef4444`, text: `#ffffff`, continuous 1.5s radial pulse for active emergency leak events.

### Floating Filter & Band Chips
- **Multispectral Band Chips:** Pill geometry (`rounded-full`), height: `28px`, padding: `0 12px`. Unselected: `#111827` with `#1f293d` outline. Selected: glowing `#00f2fe` border with cyan text and `rgba(0, 242, 254, 0.12)` fill.

### Telemetry Badges & Radar Indicators
- **Status Badges:** JetBrains Mono uppercase, `font-size: 10px`, height: `20px`, padding: `0 8px`, rounded: `9999px`. Prefixed with a pulsating 6px dot:
  - Nominal: Dot `#10b981`, background: `rgba(16, 185, 129, 0.1)`.
  - Alert: Dot `#ef4444`, background: `rgba(239, 68, 68, 0.15)`.
  - Analyzing / Orbit Pass: Dot `#f59e0b`, background: `rgba(245, 158, 11, 0.15)`.

### Geospatial Cards & Inspection Drawers
- **Plume Identification Card:** Anchored to bottom safe-area. Translucent `#111827` surface, glass blur `20px`, top border: `1px solid rgba(255, 255, 255, 0.12)`.
- Header houses landfill license name, live CH₄ flux rate (`kg/h` in `#00f2fe`), confidence percentage, and wind direction indicator vector.

### Data Inputs & Reticle Crosshairs
- **Coordinate & Search Bar:** High-contrast floating pill input with embedded search icon and satellite reticle toggle. Caret color: `#00f2fe`. Monospace placeholder text (`"LAT, LON OR FACILITY ID"`).
- **Map Crosshairs:** Center-fixed reticle with 1px hairline markers (`#00f2fe` at 40% opacity), dynamically updating corner labels with sub-second latitude/longitude coordinates.